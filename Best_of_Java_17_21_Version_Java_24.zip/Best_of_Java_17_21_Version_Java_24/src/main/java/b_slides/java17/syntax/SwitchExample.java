package b_slides.java17.syntax;

import java.time.DayOfWeek;
import java.time.Month;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class SwitchExample {

    public static void main(String[] args) {

        System.out.println(dayNameToLetterCount());
        System.out.println(monthToName(Month.FEBRUARY));
    }

    static int dayNameToLetterCount() {
        DayOfWeek day = DayOfWeek.FRIDAY;
        int numLetters = switch (day) {
            case MONDAY, FRIDAY, SUNDAY -> 6;
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
        };
        return numLetters;
    }

    static String monthToName(final Month month) {
        return switch (month) {
            case JANUARY -> "January";
            default -> "N/A"; // hier KEIN Fall Through
            case FEBRUARY -> "February";
            case MARCH -> "March";
            case JULY -> "July";
        };
    }

    enum Color {RED, GREEN, BLUE, YELLOW, ORANGE}


    public static void switchYieldReturnsValue(Color color) {
        int numOfChars = switch (color) {
            case RED:
                yield 3;
            case GREEN: yield 5;
            case YELLOW, ORANGE:
                yield 6;
            default:
				throw new IllegalArgumentException("Unexpected color: " + color);
        };

        System.out.println("color: " + color + " ==> " + numOfChars);
    }
}
