package b_slides.java17.syntax.sealed_types;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class SealedTypesExamples {
	sealed interface MathOp permits BaseOp,Add,Sub, BaseOp2 // <= erlaubte Subtypen
			//Mult, Div /* Third */ //
	{
		int calc(int x, int y);
	}

	// Mit non-sealed kann man innerhalb der Vererbungshierarchie Basisklassen
	// bereitstellen
	non-sealed class BaseOp implements MathOp // <= Basisklasse
		// permits Mult, Div /* Third */
	// nicht versiegeln
	{
		@Override
		public int calc(int x, int y) {
			return 0;
		}
	}

	sealed class BaseOp2 implements MathOp 
	{
		@Override
		public int calc(int x, int y) {
			return 0;
		}
	}

	final class Add implements MathOp {
		@Override
		public int calc(int x, int y) {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	final class Sub implements MathOp {
		@Override
		public int calc(int x, int y) {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	final class Mult extends BaseOp2 {
		@Override
		public int calc(int x, int y) {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	final class Div extends BaseOp2 {
		@Override
		public int calc(int x, int y) {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	final class Third extends BaseOp2 {
		@Override
		public int calc(int x, int y) {
			// TODO Auto-generated method stub
			return 0;
		}
	}
}