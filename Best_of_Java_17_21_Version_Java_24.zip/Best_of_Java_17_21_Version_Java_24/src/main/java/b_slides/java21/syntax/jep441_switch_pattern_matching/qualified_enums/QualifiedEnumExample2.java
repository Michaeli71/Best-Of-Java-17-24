package ch09_syntax_java_18_21.ch09_03_pattern_matching.qualified_enums;

import static ch09_syntax_java_18_21.ch09_03_pattern_matching.qualified_enums.CompassDirection.*;
import static ch09_syntax_java_18_21.ch09_03_pattern_matching.qualified_enums.PlayerDirection.*;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class QualifiedEnumExample2
{
    public static void main(String[] args)
    {
        java21Examaple(NORTH, 50);
    }

    private static void java21Examaple(Direction dir, int speed)
    {
        switch (dir)
        {
            // Mit Bedingung
            case CompassDirection d when d == NORTH && speed >= 10 ->
            {
                handleUp();
                handleUp();
            }
            case NORTH, UP -> handleUp();
            case SOUTH, DOWN -> handleDown();
            case EAST, RIGHT -> handleRight();
            case WEST, LEFT -> handleLeft();
        }
    }

    private static void handleLeft()
    {
    }

    private static void handleRight()
    {

    }

    private static void handleDown()
    {

    }

    private static void handleUp()
    {

    }
}
