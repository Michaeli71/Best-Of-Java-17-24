package b_slides.java21.api.virtualthreads;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class FirstVirtualThreadsExample
{
    public static void main(String[] args) throws InterruptedException {
        Runnable action = () -> {
            var currentThread = Thread.currentThread();
            System.out.println("name: " + currentThread.getName() +
                    " isVirtual(): " + currentThread.isVirtual());
        };

        var platformThread = Thread.ofPlatform().name("myPlatform").unstarted(action);
        platformThread.start();

        var virtualThread = Thread.ofVirtual().name("myFirstVirtual").unstarted(action);
        virtualThread.start();

        virtualThread.join();
        System.out.println("is Thread? " + (virtualThread instanceof Thread));

        Thread.startVirtualThread(action);
    }
}
