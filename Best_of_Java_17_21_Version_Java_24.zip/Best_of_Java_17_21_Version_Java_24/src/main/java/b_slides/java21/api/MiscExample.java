package b_slides.java21.api;

import java.util.Arrays;
import java.util.random.RandomGenerator;
import java.util.stream.IntStream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class MiscExample {
    public static void main(String[] args) {
        var sb = new StringBuffer();
        sb.repeat('*', 10);
        System.out.println(sb.toString());

        var tomAndJerry = "tom:and::jerry:::news---ticker---top";

        String[] splits = tomAndJerry.splitWithDelimiters(":+", 3);
        System.out.println(Arrays.toString(splits));

        String[] splits2 = tomAndJerry.splitWithDelimiters("(:+|-{3})", 4);
        System.out.println(Arrays.toString(splits2));

        String[] splits3 = tomAndJerry.splitWithDelimiters("(:+|-{3})", 5);
        System.out.println(Arrays.toString(splits3));

        String[] splits4 = tomAndJerry.splitWithDelimiters("(:+|-{3})", 6);
        System.out.println(Arrays.toString(splits4));
    }
}
