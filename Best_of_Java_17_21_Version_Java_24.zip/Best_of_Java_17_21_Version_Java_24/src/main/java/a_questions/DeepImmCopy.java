package a_questions;

import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class DeepImmCopy 
{
	public static void main(String[] args) {

		List<String> names = Arrays.asList("Tim", "Tom", "Mike");
		List<String> names2 = Arrays.asList("Tim2", "Tom2", "Mike2");
		List<String> names3 = Arrays.asList("Tim3", "Tom3", "Mike3");

		List<List<String>> all = Arrays.asList(names, names2, names3);
		System.out.println(all.getClass());
		System.out.println(all.get(0).getClass());

		List<List<String>> copy = List.copyOf(all);
		System.out.println(copy.getClass());
		System.out.println(copy.get(0).getClass());
	}
}
