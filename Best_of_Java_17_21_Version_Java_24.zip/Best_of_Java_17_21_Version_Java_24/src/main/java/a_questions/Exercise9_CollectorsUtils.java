package a_questions;

import java.util.function.Predicate;
import java.util.stream.Collector;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Exercise9_CollectorsUtils 
{
	public static <T, A, R> Collector<T, A, R> filtering(final Predicate<? super T> filter, 
			                                             final Collector<T, A, R> collector) 
	{
		  return Collector.of(
		      collector.supplier(),
		      
		      // TRICK
		      (accumulator, input) -> {
		         if (filter.test(input)) {
		            collector.accumulator().accept(accumulator, input);
		         }
		      },		      
		      
		      collector.combiner(),
		      collector.finisher());
	}
}
