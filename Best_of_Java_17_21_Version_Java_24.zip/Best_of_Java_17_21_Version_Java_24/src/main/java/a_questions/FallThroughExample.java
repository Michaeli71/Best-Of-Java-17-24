package a_questions;

import java.time.Month;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class FallThroughExample {

	public static void main(String[] args) {

		printMonth(Month.JULY);
		printMonth(Month.APRIL);
	}

	private static void printMonth(Month month) {
		String monthString = "";
		switch (month) {
		case JANUARY:
			monthString = "January";
			break;
		default:
			monthString = "N/A"; // hier auch noch Fall Through
		case FEBRUARY:
			monthString = "February";
			break;
		case MARCH:
			monthString = "March";
			break;
		case JULY:
			monthString = "July";
			break;
		}

		System.out.println("OLD: " + month + " = " + monthString); // February
	}
}