package a_questions;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class DemoLombokReplacement
{
    private final String name;
    private LocalDate birthday;
    private int pinCode;
    
    public static void main(String[] args)
    {
        
    }

    public DemoLombokReplacement(String name, LocalDate birthday, int pinCode)
    {
        this.name = name;
        this.birthday = birthday;
        this.pinCode = pinCode;
    }

    public String getName()
    {
        return name;
    }

    public LocalDate getBirthday()
    {
        return birthday;
    }

    public void setBirthday(LocalDate birthday)
    {
        this.birthday = birthday;
    }

    public int getPinCode()
    {
        return pinCode;
    }

    public void setPinCode(int pinCode)
    {
        this.pinCode = pinCode;
    }

    // equals() & hashCode()
        
    @Override
    public int hashCode()
    {
        return Objects.hash(name);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DemoLombokReplacement other = (DemoLombokReplacement) obj;
        return Objects.equals(birthday, other.birthday) && Objects.equals(name, other.name) && pinCode == other.pinCode;
    }
    

    
}
