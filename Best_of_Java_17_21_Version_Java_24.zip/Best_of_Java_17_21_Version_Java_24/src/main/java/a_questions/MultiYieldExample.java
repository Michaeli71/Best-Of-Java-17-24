package a_questions;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class MultiYieldExample {

	public static void main(String[] args) {
		multiYield("V2", 50);
		multiYield("V1", 50);
		multiYield("V1", 51);
	}

	private static void multiYield(String version, int age) {
		String result = switch (version) {
		case "V1" -> {
			String internal = switch (age) {
			case 51 -> {
				System.out.println("51");
				yield "51";
			}
			default -> "OTHER";
			};

			yield internal += " LAST";
		}
		case "V2" -> "Version 2";
		default -> throw new IllegalArgumentException("Unexpected value: " + version);
		};

		System.out.println("Result " + result);
	}
}
