package a_questions;


/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class InstanceOfExample {

	public static void main(String[] args) {
		
	    Object obj2 = "BACSGsJAHG";
	    
        if (obj2 instanceof String) 
        {
            String str2 = (String)obj2;
            if (str2.length() > 5 && str2.startsWith("BA"))
            {
                System.out.println("Länge: " + str2.length());                
            }
        }
        
	    if (obj2 instanceof String str2 && str2.length() > 5 && str2.startsWith("BA"))
	    {
	        //str2 ="THOMAS_jashjadhkjadhj";
	        System.out.println("Länge: " + str2.length());
	    }
	}
}
