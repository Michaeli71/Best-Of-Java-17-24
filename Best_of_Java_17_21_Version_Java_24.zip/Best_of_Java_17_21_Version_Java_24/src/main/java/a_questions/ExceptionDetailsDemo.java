package a_questions;

public class ExceptionDetailsDemo {
    public static void main(String[] args) {
        Object a = null;

        // Keine Annreicherung
        if (a == null)
            throw new IllegalStateException("Check if error condition is shown");

        //a.hashCode();
    }
}
