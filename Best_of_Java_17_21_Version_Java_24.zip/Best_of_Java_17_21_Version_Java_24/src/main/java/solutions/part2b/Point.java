package solutions.part2b;


record Point(int x, int y) implements Figure {
}

record Line(Point start,
            Point end) implements Figure {
}

record Triangle(Point pointA,
                Point pointB,
                Point PointC) implements Figure {
}