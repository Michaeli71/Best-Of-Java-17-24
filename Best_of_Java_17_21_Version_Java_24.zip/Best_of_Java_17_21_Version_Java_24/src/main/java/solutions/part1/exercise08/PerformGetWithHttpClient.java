package solutions.part1.exercise08;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class PerformGetWithHttpClient 
{
	public static void main(String[] args) throws Exception 
	{
		var client = HttpClient.newBuilder().build();
		URI uri = URI.create("https://reqres.in/api/unknown/2");
		var request = HttpRequest.newBuilder().GET().uri(uri).build();
		
		var response = client.send(request, BodyHandlers.ofString());
		System.out.printf("Response code is: %d %n", response.statusCode());
		System.out.printf("The response body is:%n %s %n", response.body());
	}
}