package exercises.part1;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Exercise01_switch 
{
	public static void main(final String[] args) {

		int value = 7;

		dumbEvenOddChecker(value);
	}

	private static void dumbEvenOddChecker(final int value) {
		String result;

		switch (value) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 9:
				result = "odd";
				break; // remove for FALL THROUGH DEMONSTRATION

		case 0, 2, 4, 6, 8, 10:
			result = "even";
			break;

		default:
			result = "only implemented for values <= 10";
		}

		System.out.println("result: " + result);
	}
}
