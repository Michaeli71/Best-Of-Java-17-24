package jep484_Class_File_Api.bonus;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class ExampleDebug {

    public static void main(final String[] args) {
        debugOutput1();
        debugOutput2();
        System.out.println("Normal Statement");
    }

    public static void debugOutput1()
    {
        System.out.println("Some JEPs");
    }

    public static void debugOutput2()
    {
        System.out.println("Noch mehr JEPs");
    }

}
