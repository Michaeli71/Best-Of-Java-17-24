package jep488_Primitive_Types_in_Patterns;

import static java.io.IO.println;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class PerfectIntFloatMatches
{
    public static void main(String[] args)
    {
        calcMatchingStatistics();
    }

    static void calcMatchingStatistics()
    {
        var nonMatchingCount = new AtomicInteger();
        var matchingCount = new AtomicInteger();

        // bis 10_000_000 => keine Abweichung
        int MIN = -10_000_000;
        int MAX = 50_000_000;
        IntStream.range(MIN, MAX).forEach(i -> {
            float floatValue = i;

            int floatValueAsInt = (int) floatValue;

            if (i != floatValueAsInt) {
                nonMatchingCount.incrementAndGet();
            } else {
                matchingCount.incrementAndGet();
            }
        });

        printStatistics(nonMatchingCount, matchingCount, MAX, MIN);
    }

    private static void printStatistics(AtomicInteger nonMatchingCount,
                                        AtomicInteger matchingCount,
                                        int MAX, int MIN)
    {
        println("float/int values");
        println("non matching: " + nonMatchingCount.get());
        println("    matching: " + matchingCount.get());
        println("       total: " + (matchingCount.get() + nonMatchingCount.get()));

        println("in %");
        println("non matching %: " + (Math.round(100.00d / (MAX - MIN) * nonMatchingCount.get())));
        println("    matching %: " + (Math.round(100.00d / (MAX - MIN) * matchingCount.get())));
    }
}
