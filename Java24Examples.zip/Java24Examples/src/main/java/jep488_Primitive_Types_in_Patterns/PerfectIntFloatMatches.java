package jep488_Primitive_Types_in_Patterns;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

import static java.io.IO.println;

public class PerfectIntFloatMatches
{
    public static void main(String[] args)
    {
        calcMatchingStatistics();
    }

    static void calcMatchingStatistics()
    {
        var nonMatchingCount = new AtomicInteger();
        var matchingCount = new AtomicInteger();

        // bis 10_000_000 => keine Abweichung
        int MIN = -10_000_000;
        int MAX = 50_000_000;
        IntStream.range(MIN, MAX).forEach(i -> {
            float floatValue = i;

            int floatValueAsInt = (int) floatValue;

            if (i != floatValueAsInt) {
                nonMatchingCount.incrementAndGet();
            } else {
                matchingCount.incrementAndGet();
            }
        });

        printStatistics(nonMatchingCount, matchingCount, MAX, MIN);
    }

    private static void printStatistics(AtomicInteger nonMatchingCount,
                                        AtomicInteger matchingCount,
                                        int MAX, int MIN)
    {
        println("float/int values");
        println("non matching: " + nonMatchingCount.get());
        println("    matching: " + matchingCount.get());
        println("       total: " + (matchingCount.get() + nonMatchingCount.get()));

        println("in %");
        println("non matching %: " + (Math.round(100.00d / (MAX - MIN) * nonMatchingCount.get())));
        println("    matching %: " + (Math.round(100.00d / (MAX - MIN) * matchingCount.get())));
    }
}
