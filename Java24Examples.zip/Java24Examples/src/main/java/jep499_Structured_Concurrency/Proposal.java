package jep499_Structured_Concurrency;

import java.util.List;

public record Proposal(List<String> hotels, List<String> carRentals) {
}
