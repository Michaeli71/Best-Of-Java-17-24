package jep499_Structured_Concurrency;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.StructuredTaskScope;

import static java.io.IO.println;

public class NestedStructuredConcurrencyExample {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        var city = "Zürich";
        var startDate = "2022-01-01";

        println(performCityTripProposals(city, LocalDate.parse(startDate)));
    }

    private static Proposal performCityTripProposals(String city, LocalDate startDate) throws InterruptedException, ExecutionException {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
            var hotelSubtask = scope.fork(() -> findHotels(city, startDate));
            var carRentalSubtask = scope.fork(() -> fetchCarRentals(city, startDate));

            scope.join();          // Join both forks
            scope.throwIfFailed(); // ... and propagate errors

            // Here, both forks have succeeded, so compose their results
            return new Proposal(hotelSubtask.get(), carRentalSubtask.get());
        }
    }

    private static List<String> findHotels(String city, LocalDate startDate) throws InterruptedException, ExecutionException {
        try (var scope = new StructuredTaskScope.ShutdownOnSuccess<String>()) {
            StructuredTaskScope.Subtask<String> proposal1 = scope.fork(() -> findPropsalTrivago(city, startDate));
            StructuredTaskScope.Subtask<String> proposal2 = scope.fork(() -> findProposalBooking(city, startDate));
            StructuredTaskScope.Subtask<String> proposal3 = scope.fork(() -> findPropsalCheck24(city, startDate));

            scope.join();

            // Hier kommt der Wunsch nach FirstNSuccessful auf
            // Achtung: ShutdownOnSuccess muss passend den generischen Parameter bekommen
            return List.of(scope.result());
        }
    }

    private static String findProposalBooking(String city, LocalDate startDate) {
        randomLyWaitUpToSecond();
        return "Booking Hotel";
    }

    private static String findPropsalTrivago(String city, LocalDate startDate) {
        randomLyWaitUpToSecond();
        return "Trivago Hotel";
    }

    private static String findPropsalCheck24(String city, LocalDate startDate) {
        randomLyWaitUpToSecond();
        return "Check24 Hotel";
    }



    private static List<String> fetchCarRentals(String city, LocalDate startDate) throws InterruptedException, ExecutionException {
        try (var scope = new StructuredConcurrencOwnTaskScopeExample.FirstNSuccessful<String>(2)) {
            var proposal1 = scope.fork(() -> findPropsalEuropcar(city, startDate));
            var proposal2 = scope.fork(() -> findPropsalAvis(city, startDate));
            var proposal3 = scope.fork(() -> findPropsalHertz(city, startDate));

            scope.join();

            return scope.result();
        }
    }

    private static String findPropsalEuropcar(String city, LocalDate startDate) {
        randomLyWaitUpToSecond();
        return "Europcar";
    }

    private static void randomLyWaitUpToSecond() {
        try {
            Thread.sleep((long)(Math.random() * 1000));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static String findPropsalAvis(String city, LocalDate startDate) {
        randomLyWaitUpToSecond();
        return "Avis";
    }

    private static String findPropsalHertz(String city, LocalDate startDate) {
        randomLyWaitUpToSecond();
        return "Hertz";
    }
}
