package work.solutions.exercise1_markdown;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */

/// Ich ❤️ Markdown!\
/// Zweite Zeile
///
/// - Erster Punkt
/// - Zweiter Punkt
///   - Unterpunkt
///   - Noch ein Unterpunkt
/// - Dritter Punkt
///
/// ## Trennlinien
///
/// ---
/// oder
/// ***
/// oder
/// ___
/// ## Zitat
/// > Dies ist ein Zitat.
/// > Es kann auch mehrere Zeilen umfassen.
/// >> Und sogar verschachtelt werden!
///
/// ## Tabellen
///
/// | Spalte 1 | Spalte 2 | Spalte 3 |
/// |----------|----------|----------|
/// | Inhalt 1 | Inhalt 2 | Inhalt 3 |
/// | Text A   | Text B   | Text C   |
///
/// | Links | Mitte | Rechts |
/// |:------|:-----:|-------:|
/// | L1    |  M1   |     R1 |
/// | linksbündig   |  zentriert   |     rechtsbündig |
///
public class MarkdownExample {

    /// # Einkaufsliste
    ///
    /// ## Supermarkt
    /// - Brot
    /// - Milch
    /// - Eier
    /// - Obst:
    ///   - Erdbeeren
    ///   - Bananen
    ///
    /// - Gemüse:
    ///   - Tomaten
    ///   - Bio-Gurke
    ///   - Paprika
    ///
    /// ## Baumarkt
    /// - Duschvorhang
    /// - Pinsel
    public static void shoppingList()
    {}


    /// # Chocolate Cookies
    ///
    /// ## Zutaten
    /// - 350g Mehl
    /// - 200g Butter
    /// - 120g Zucker
    /// - 3 Eier
    /// - 1 Pck. Vanillezucker
    /// - 250g dunkle Schokolade
    ///
    /// ## Zubereitung
    /// 1. Butter und Zucker cremig rühren
    /// 2. Eier unterrühren
    /// 3. Mehl und Vanillezucker hinzufügen
    /// 4. dunkle Schokolade unterheben
    /// 5. Bei 180°C rund 12-15 Min. backen
    ///
    /// **Tipp**: Teig 30 Min. kühlen für bessere Konsistenz!
    ///
    /// ## Nährwerte
    /// | Pro Cookie | Menge |
    /// |------------|-------|
    /// | Kalorien   | 210   |
    /// | Protein    | 3g    |
    /// | Kohlenhydrate | 20g |
    /// | Fett | 20g |
    ///
    public static void cookiesRecipe()
    {}

}
