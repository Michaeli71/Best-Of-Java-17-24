package work.solutions.exercise6_primitive_type_patterns;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class PrimitiveTypePatterns {
    public static void main(String[] args) {

        int value = 42;

        switch (value) {
            case int i when i > 0 && i < 10 -> log(i + " is lower than 10");
            case int i when i >= 10 && i < 40 -> log(i + " is lower than 40");
            case int i when i >= 40 && i < 70 -> log(i + " is >= 40");
            case int i -> log("Some unexpected value is perfect: " + i);
        }
    }

private static void log(final String str) {
    System.out.println(str);
}
}
