package jep494_Module_import_Declarations;

import javax.swing.*;
import java.io.IO;
import java.util.List;
import java.util.stream.Stream;

public class InitialModuleImportExample3_V2
{
    public static void main(final String[] args)
    {
        List<String> result = Stream.of("AB", "BC", "CD", "DE").
                              filter(str -> str.contains("C")).
                              toList();
        System.out.println(result);

        IO.print("New Style IO");

        JOptionPane.showMessageDialog(null, "Info");
    }
}
