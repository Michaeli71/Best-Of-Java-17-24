package jep485_Stream_Gatherers;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import java.util.stream.Gatherer;
import java.util.stream.Stream;

import static java.io.IO.println;

public class TripleGathererExample {
    void main()
    {
        var result = Stream.of("This", "is", "a", "test").
                gather(triple()).
                toList();
        println(result);

        var result2 = Stream.of(1, 2, 3, 4, 5).
                gather(triple()).
                toList();
        println(result2);
    }


    <T> Gatherer<T, Object, T> triple()
    {
        return new Gatherer<T, Object, T>()
        {
            @Override
            public Integrator<Object, T, T> integrator()
            {
                return new Integrator<Object, T, T>()
                {
                    @Override
                    public boolean integrate(Object unusedState, T element,
                                             Downstream<? super T> downstream)
                    {
                        downstream.push(element);
                        downstream.push(element);
                        downstream.push(element);

                        return true;
                    }
                };
            }
        };
    }


    <T> Gatherer<T, AtomicInteger, T> every2ndTriple()
    {
        return new Gatherer<T, AtomicInteger, T>()
        {
            @Override
            public Supplier<AtomicInteger> initializer()
            {
                return () -> new AtomicInteger(0);
            }
            @Override
            public Integrator<AtomicInteger, T, T> integrator()
            {
                return new Integrator<AtomicInteger, T, T>()
                {
                    @Override
                    public boolean integrate(AtomicInteger state, T element,
                                             Downstream<? super T> downstream)
                    {
                        if (state.getAndIncrement() % 2 == 0)
                        {
                            downstream.push(element);
                            downstream.push(element);
                            downstream.push(element);
                        }
                        return true;
                    }
                };
            }
        };
    }

    <T> Gatherer<T, AtomicInteger, T> every2ndTripleAgain()
    {
        return Gatherer.ofSequential(
                AtomicInteger::new,
                (state, element, downstream) ->
                {
                    if (state.getAndIncrement() % 2 == 0)
                    {
                        downstream.push(element);
                        downstream.push(element);
                        downstream.push(element);
                    }
                    return true;
                },
                Gatherer.defaultFinisher()
        );
    }
}
