void main()
{
    var name = readln("Please enter your name: ");
    println("Hello " + name);
}
